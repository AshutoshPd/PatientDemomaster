﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PatientDemoMaster;
using PatientDemoMaster.Controllers;
using PatientService;
using PatientDemoMaster.Models;

namespace PatientDemoMaster.Tests.Controllers {
    [TestClass]
    public class ValuesControllerTest {
        [TestMethod]
        public void Get() {
            // Arrange
            ValuesController controller = new ValuesController();

            // Act
            var result = controller.Get();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Post() {
            // Arrange
            ValuesController controller = new ValuesController();

            // Act
            Contact contact = new Contact() {
                HomeNumber = "1111",
                MobileNumber = "2222",
                OfficeNumber = "3333"
            };
            PatientData patient = new PatientData() {
                ForeName = "Abc",
                SurName = "c",
                Contact = contact,
                DateOfBirth = DateTime.Now,
                Gender = "M"
            };
            controller.Post(patient);
            
            // Assert
        }
    }
}
