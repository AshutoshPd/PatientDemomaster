﻿using PatientDemoMaster.Models;
using PatientService;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace PatientDemoMaster.Helper {
    public class Helper {
        public static IEnumerable<PatientData> DbToModel(List<Patient> patients) {
            try {
                if(patients?.Count < 1) {
                    throw new Exception("Input Value is null.");
                }
                List<PatientData> patientsdata = new List<PatientData>();
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(PatientData));
                foreach(Patient pat in patients) {
                    PatientData patientData = (PatientData)xmlSerializer.Deserialize(
                        new System.IO.MemoryStream(Encoding.UTF8.GetBytes(@pat.Patient1)));
                    patientData.Id = pat.Id;
                    patientsdata.Add(patientData);
                }
                return patientsdata;
            } catch { throw new Exception("Unexpected error occured!"); }

        }

        public static Patient ModelToDb(PatientData patientData) {
            try {
                var stringwriter = new System.IO.StringWriter();
                var serializer = new XmlSerializer(patientData.GetType());
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(Patient));
                serializer.Serialize(stringwriter, patientData);
                var data = stringwriter.ToString();
                Patient patient = new Patient() {
                    Patient1 = data.Substring(data.IndexOf("<Patient"))
                };
                return patient;
            } catch { throw new Exception("Unexpected error occured!"); }
        }
    }
}