﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace PatientDemoMaster.Models {
    [Serializable, XmlRoot("Contact")]
    public class Contact {
        [Display(Name = "Home Number")]
        [DataType(DataType.PhoneNumber)]
        public string HomeNumber { get; set; }

        [Display(Name = "Office Number")]
        [DataType(DataType.PhoneNumber)]
        public string OfficeNumber { get; set; }

        [Display(Name = "Mobile Number")]
        [DataType(DataType.PhoneNumber)]
        public string MobileNumber { get; set; }
    }
}