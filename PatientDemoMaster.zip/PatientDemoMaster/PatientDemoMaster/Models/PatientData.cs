﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace PatientDemoMaster.Models {
    [Serializable, XmlRoot("Patient")]
    public class PatientData {
        public int Id { get; set; }
        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Enter your ForeName")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 50 char")]
        [DataType(DataType.Text)]
        public string ForeName { get; set; }
        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Enter your SurName")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 char")]
        [DataType(DataType.Text)]
        public string SurName { get; set; }

        [Display(Name = "Gender")]
        [Required(ErrorMessage = "Enter your Gender")]
        [DataType(DataType.Text)]
        public string Gender { get; set; }
        [Required]
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
        public Contact Contact { get; set; }
    }
}