﻿using PatientDemoMaster.Models;
using PatientService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace PatientDemoMaster.Controllers {
    public class ValuesController : ApiController {
        // GET api/values
        public IEnumerable<PatientData> Get() {
            try {
                var patientData = new List<PatientData>();
                using(ptdbEntities entities = new ptdbEntities()) {
                    var patients = entities.Patients.ToList();
                    patientData = Helper.Helper.DbToModel(patients).ToList();
                }
                return patientData;
            } catch(Exception ex) { throw ex; }
        }

        // POST api/values
        public void Post(PatientData patientData) {
            try {
                var patient = Helper.Helper.ModelToDb(patientData);
                using(ptdbEntities entities = new ptdbEntities()) {
                    entities.Patients.Add(patient);
                    entities.SaveChanges();
                }
            } catch(Exception ex) { throw ex; }
        }
    }
}
