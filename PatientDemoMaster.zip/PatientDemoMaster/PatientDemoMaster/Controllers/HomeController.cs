﻿using PatientDemoMaster.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace PatientDemoMaster.Controllers {
    public class HomeController : Controller {
        ValuesController controller = new ValuesController();
        public ActionResult Index() {
            try {
                List<PatientData> patients = new List<PatientData>();
                patients = controller.Get().ToList();
                return View(patients);
            } catch {
                return RedirectToAction("Error");
            }
        }

        [HttpGet]
        public ActionResult Create() {
            try {
                return View();
            } catch {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(PatientData patient) {
            try {
                controller.Post(patient);
                return RedirectToAction("Index");
            } catch {
                return RedirectToAction("Error");
            }
        }

        public ActionResult Error() {
            return View();
        }

    }
}
